import React from 'react'

const ServicePage = () => {
  return (
    <div>ServicePage</div>
  )
}

export default ServicePage